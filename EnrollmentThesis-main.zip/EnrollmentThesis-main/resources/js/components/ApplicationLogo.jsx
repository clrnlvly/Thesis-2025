import WITI from "../../assets/WITI-icon.png";

export default function ApplicationLogo(props) {
    return <img {...props} src={WITI} alt="WITI" />;
}
