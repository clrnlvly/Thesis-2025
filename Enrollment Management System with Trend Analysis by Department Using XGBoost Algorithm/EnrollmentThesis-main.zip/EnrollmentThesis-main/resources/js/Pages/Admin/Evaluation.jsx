import Layout from "@/components/layout";
import React, { useState } from "react";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";
import SearchFilter from "@/components/SearchFilter";
import FilterDropdown from "@/components/FilterDropdown";
import BadgeSuccess from "@/components/BadgeSuccess";
import BadgeWarning from "@/components/BadgeWarning";
import BadgeDanger from "@/components/BadgeDanger";
import RowPerPage from "@/components/RowPerPage";
import Pagination from "@/components/Pagination";
import useDebouncedSearch from "@/components/utils/useDebounceSearch";
import { router } from "@inertiajs/react";
import NoData from "@/components/no-data";

export default function Evaluation({ evaluation, filters }) {
    const evaluationData = evaluation?.data || [];

    const getStatusBadge = (status) => {
        const statusLower = String(status).toLowerCase();

        switch (statusLower) {
            case "approved":
            case "fully paid":
            case "cleared":
            case "available":
            case "passed (college)":
                return <BadgeSuccess>{status}</BadgeSuccess>;

            case "pending":
            case "partially paid":
                return <BadgeWarning>{status}</BadgeWarning>;

            case "rejected":
            case "unpaid":
            case "not cleared":
            case "unavailable":
                return <BadgeDanger>{status}</BadgeDanger>;

            default:
                return (
                    <span className="px-2 py-1 text-xs font-medium rounded-full bg-gray-100 text-gray-800">
                        {status}
                    </span>
                );
        }
    };

    const filterData = {
        Year: [
            "Grade 11",
            "Grade 12",
            "1st Year",
            "2nd Year",
            "3rd Year",
            "4th Year",
        ],
        Semester: ["1st Semester", "2nd Semester"],
        Clearance: ["Cleared", "Not Cleared"],
    };

    const [search, setSearch] = useState(filters?.search || "");
    const [dataFilter, setDataFilter] = useState("All");
    const [perPage, setPerPage] = useState(filters?.per_page || 10);

    const { triggerSearch } = useDebouncedSearch({
        routeName: "admin.evaluation",
        filterKey: "filter",
        filterValue: dataFilter,
        perPage,
    });

    const handleSearchChange = (val) => {
        setSearch(val);
        triggerSearch(val);
    };

    const year = sessionStorage.getItem("selectedYear");

    const handleFilterChange = (filterValue) => {
        setDataFilter(filterValue);
        router.get(
            route("admin.evaluation"),
            {
                search: "",
                filter: filterValue === "All" ? "" : filterValue,
                per_page: perPage,
                year,
            },
            {
                preserveState: true,
                replace: true,
            }
        );
    };

    const clearAllFilters = () => {
        const year = sessionStorage.getItem("selectedYear");
        setSearch("");
        setDataFilter("All");

        router.get(
            route("admin.evaluation"),
            {
                search: "",
                filter: "",
                per_page: perPage,
                year: year || "",
            },
            {
                preserveState: true,
                replace: true,
            }
        );
    };

    return (
        <Layout>
            <div className="flex items-end justify-between mb-7">
                <h1 className="text-2xl font-bold">Evaluation</h1>
            </div>

            <div className="flex justify-between gap-4 mb-4">
                <div className="flex items-center gap-2">
                    <SearchFilter
                        searchValue={search}
                        onSearchChange={handleSearchChange}
                        onSearchSubmit={triggerSearch}
                        onClearFilters={clearAllFilters}
                        showClearButton={search || dataFilter !== "All"}
                    />
                    <FilterDropdown
                        currentFilter={dataFilter}
                        filterData={filterData}
                        onFilterChange={handleFilterChange}
                    />
                </div>
                <div className="flex items-center gap-4"></div>
            </div>

            <div className="w-full overflow-x-auto rounded-lg border min-h-96">
                <Table className="w-full">
                    <TableHeader>
                        <TableRow>
                            <TableHead className="w-[12.5%] text-center">
                                Student ID
                            </TableHead>
                            <TableHead className="w-[12.5%] text-center">
                                Student Name
                            </TableHead>
                            <TableHead className="w-[12.5%] text-center">
                                Semester
                            </TableHead>
                            <TableHead className="w-[12.5%] text-center">
                                Year Level
                            </TableHead>
                            <TableHead className="w-[12.5%] text-center">
                                Clearance
                            </TableHead>
                            <TableHead className="w-[12.5%] text-center">
                                Grades
                            </TableHead>
                            <TableHead className="w-[12.5%] text-center">
                                Documents
                            </TableHead>
                            <TableHead className="w-[12.5%] text-center">
                                Payment
                            </TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {evaluationData.length > 0 ? (
                            evaluationData.map((item) => (
                                <TableRow key={item.id}>
                                    <TableCell className="text-center">
                                        {item.student_info_id}
                                    </TableCell>
                                    <TableCell className="text-center">
                                        {item.student_name}
                                    </TableCell>
                                    <TableCell className="text-center">
                                        {item.semester}
                                    </TableCell>
                                    <TableCell className="text-center">
                                        {item.year_level}
                                    </TableCell>
                                    <TableCell className="text-center">
                                        {getStatusBadge(item.clearance)}
                                    </TableCell>
                                    <TableCell className="text-center">
                                        {getStatusBadge(item.grades_eval)}
                                    </TableCell>
                                    <TableCell className="text-center">
                                        {getStatusBadge(item.documents)}
                                    </TableCell>
                                    <TableCell className="text-center">
                                        {getStatusBadge(item.payment)}
                                    </TableCell>
                                </TableRow>
                            ))
                        ) : (
                            <TableRow>
                                <TableCell
                                    colSpan={8}
                                    className="text-center py-8"
                                >
                                    <NoData />
                                </TableCell>
                            </TableRow>
                        )}
                    </TableBody>
                </Table>
            </div>
            <div className="flex justify-between pt-2">
                <RowPerPage
                    filters={filters}
                    routeName={"admin.evaluation"}
                    dataFilter={dataFilter}
                />
                <Pagination links={evaluation?.links} />
            </div>
        </Layout>
    );
}
